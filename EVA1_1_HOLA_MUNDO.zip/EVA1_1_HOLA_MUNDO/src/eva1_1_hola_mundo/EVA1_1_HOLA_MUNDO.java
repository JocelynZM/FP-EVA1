/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_1_hola_mundo;

public class EVA1_1_HOLA_MUNDO {

   //PRINCIPIO
    public static void main(String[] args) {
        
        System.out.println("HOLA MUNDO");
        System.out.println("FUNDAMENTOS DE PROGRAMACIÓN");
        
        //MENSAJE
        
    }//FIN 
    
}
